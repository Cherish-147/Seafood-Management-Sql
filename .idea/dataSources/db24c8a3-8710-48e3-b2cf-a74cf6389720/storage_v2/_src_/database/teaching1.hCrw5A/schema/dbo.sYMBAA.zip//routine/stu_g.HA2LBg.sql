CREATE PROCEDURE stu_g
@cid char(4)
AS
SELECT student.* FROM student INNER JOIN sc ON student.sno=sc.sno
WHERE cno=@cid
go

