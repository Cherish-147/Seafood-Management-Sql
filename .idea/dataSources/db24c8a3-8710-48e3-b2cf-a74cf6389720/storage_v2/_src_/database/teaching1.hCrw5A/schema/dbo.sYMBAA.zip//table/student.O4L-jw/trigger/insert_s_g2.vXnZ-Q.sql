create trigger insert_s_g2
on student
after insert
as begin
      declare @sid char(9),@cid char(4)
	  select @sid=sno from  inserted
	  select @cid=cno from course  where cname='数据库原理与应用'
	  insert into sc(sno,cno)
	  values(@sid,@cid)
	print'该学生选课信息已录入sc表'
	end
go

