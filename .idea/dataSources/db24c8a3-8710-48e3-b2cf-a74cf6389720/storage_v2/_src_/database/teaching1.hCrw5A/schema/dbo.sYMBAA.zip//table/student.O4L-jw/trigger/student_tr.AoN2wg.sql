create trigger student_tr
on student
after insert,update
as
begin
	select *from inserted
	select *from deleted
end
go

