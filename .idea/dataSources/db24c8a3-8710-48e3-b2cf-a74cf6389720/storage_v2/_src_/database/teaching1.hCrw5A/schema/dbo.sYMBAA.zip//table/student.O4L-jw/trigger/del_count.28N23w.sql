create  trigger del_count
on student after delete
as
declare @count int;
    set @count = (select count(*)from deleted);
    print '删除了' +convert(varchar, @count)  + '个学生信息'

go

