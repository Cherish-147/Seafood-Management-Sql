-- a)	借出图书视图
create view 借出图书
as
    select * from 图书 where 图书状态='借出'
go

