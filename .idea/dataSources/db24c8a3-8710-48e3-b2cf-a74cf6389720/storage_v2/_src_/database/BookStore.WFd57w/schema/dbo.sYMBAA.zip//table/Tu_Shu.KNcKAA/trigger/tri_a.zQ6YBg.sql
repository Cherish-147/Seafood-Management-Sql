create trigger tri_a
on 图书 after update
as
declare @status nchar(2)
--declare @status char(4)
declare @ISBN char(20)
select @status=图书状态 from inserted
select @ISBN=ISBN from inserted
if user_name()='oper1'
begin

    if @status='借出'
insert into 借还书登记(ISBN,借书办理人,借书时间)
values
    (@ISBN,user_name(),getdate())
else if @status='库存'
update 借还书登记
set 还书办理人=user_name(),归还时间=getdate()
where ISBN=@ISBN

end
go

