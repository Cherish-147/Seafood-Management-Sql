create trigger tri_b
on 催还书登记 after delete
as
if user_name()='oper1'
begin
    if (select count(*)from deleted)>0
    rollback
end
go

