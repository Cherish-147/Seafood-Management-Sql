create procedure proc_getBooklog
@bookname nchar(20),
@ISBN char(20)
as
    begin
        select 教.姓名,图.图书名,借还.借书时间,归还时间 from 借还书登记 借还 join 教师 教 on 借还.教工号 = 教.教工号
        join 图书 图 on 借还.ISBN = 图.ISBN
        where 借还.ISBN=@ISBN or 图.图书名=@bookname
    end;

DROP PROCEDURE proc_getBooklog;
go

