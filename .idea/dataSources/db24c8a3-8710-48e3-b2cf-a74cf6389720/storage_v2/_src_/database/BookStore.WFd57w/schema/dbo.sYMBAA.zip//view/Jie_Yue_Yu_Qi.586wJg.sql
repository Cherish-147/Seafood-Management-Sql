-- b)	借阅逾期视图
create view 借阅逾期
as
select 借还书登记.借书办理人,借还书登记.教工号,图书.图书名 from 图书 inner join 借还书登记  on 图书.ISBN = 借还书登记.ISBN
                   inner join 图书类型  on 图书.类别名 = 图书类型.类别名
where 图书.图书状态='借出' and datediff(day,借还书登记.借书时间,getdate())>图书类型.借阅期限
go

