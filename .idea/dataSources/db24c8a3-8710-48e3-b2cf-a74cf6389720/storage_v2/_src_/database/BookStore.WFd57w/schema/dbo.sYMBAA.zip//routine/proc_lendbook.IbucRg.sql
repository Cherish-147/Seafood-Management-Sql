-- 2）	设计存储过程
-- a)	某教师在某时间借了某本书，由某管理员办理。
create procedure proc_lendbook
@aid char(20),
@atime datetime,
@ISBN char(20),
@aname char(10)
as
begin
    update 图书
    set 图书状态='借出'
    where ISBN=@ISBN
    insert into 借还书登记(ISBN,教工号,借书办理人,借书时间)
    values (@ISBN,@aid,@aname,@atime)
end;
go

