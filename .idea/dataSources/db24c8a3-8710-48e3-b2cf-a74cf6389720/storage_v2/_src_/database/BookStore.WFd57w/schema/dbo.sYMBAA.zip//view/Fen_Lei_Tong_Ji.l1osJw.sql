-- c)	图书分类统计册数视图
create view 分类统计
as
    select count(*) as 书籍册数,类别名
    from 图书 group by 类别名
go

