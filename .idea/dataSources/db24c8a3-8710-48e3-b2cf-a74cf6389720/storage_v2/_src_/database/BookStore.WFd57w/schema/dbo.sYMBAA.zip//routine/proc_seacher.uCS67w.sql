create procedure proc_seacher
@bookname nchar(20),
@max tinyint
as
    begin
    select * from 图书
        where datediff(year,出版时间,getdate())<@max and
              --图书名 like '%数据库%' +@bookname +'%数据库%'
              图书名 like '%' +@bookname +'%'

end
go

