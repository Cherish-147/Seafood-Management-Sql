create proc proc_list1
@cid char(4)
as
select top 3 *
from sc
where cno=@cid
order by score desc

exec proc_list1 'E002'
go

