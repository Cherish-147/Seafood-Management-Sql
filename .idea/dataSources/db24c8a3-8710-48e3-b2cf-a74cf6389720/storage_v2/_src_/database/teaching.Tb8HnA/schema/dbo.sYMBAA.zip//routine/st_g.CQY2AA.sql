CREATE PROCEDURE st_g
AS
BEGIN
    SELECT x.sno 学号,x.sname 姓名,y.cno 课程号
    FROM student  x , sc y
    Where x.sno=y.sno
END;
go

