create proc proc_tel
as
select *from student where telephone like '%5'
;
go

