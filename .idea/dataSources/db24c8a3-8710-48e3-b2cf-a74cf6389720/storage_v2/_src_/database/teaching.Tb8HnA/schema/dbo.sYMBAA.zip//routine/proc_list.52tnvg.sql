create proc proc_list
@cid char(4)
as
select top 3 *from sc
where cno=@cid
order by score desc;
go

