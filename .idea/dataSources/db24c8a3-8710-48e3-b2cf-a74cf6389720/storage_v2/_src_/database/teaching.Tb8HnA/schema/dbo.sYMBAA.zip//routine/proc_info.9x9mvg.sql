CREATE proc proc_info
@cname nvarchar(20),
@begin_sc int,                   
@end_sc int
as
select student.sno,student.sname,sc.score
from student join sc on student.sno=sc.sno join course on course.cno=sc.cno
where cname=@cname and score>=@begin_sc and score<=@end_sc
go

