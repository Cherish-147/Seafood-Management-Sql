create  proc proc_avg1
as
select sno,avg(score) 平均成绩
from sc
group by sno
go

