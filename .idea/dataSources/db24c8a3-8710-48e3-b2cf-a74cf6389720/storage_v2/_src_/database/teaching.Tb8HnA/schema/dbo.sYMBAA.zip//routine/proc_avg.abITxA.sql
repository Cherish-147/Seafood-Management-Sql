CREATE PROCEDURE proc_avg
AS
BEGIN
    SELECT x.sno 学号,x.sname 姓名,y.score 分数,AVG(score) 平均分
    FROM student  x , sc y
	
    Where x.sno=y.sno
	group by x.sno,x.sname,y.score
END;
go

