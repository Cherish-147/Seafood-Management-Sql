create proc proc_cour(
@cname nvarchar(20),
@avg_sc int output)
as
select @avg_sc=AVG(score)
from sc join course on sc.cno=course.cno
where cname=@cname
go

