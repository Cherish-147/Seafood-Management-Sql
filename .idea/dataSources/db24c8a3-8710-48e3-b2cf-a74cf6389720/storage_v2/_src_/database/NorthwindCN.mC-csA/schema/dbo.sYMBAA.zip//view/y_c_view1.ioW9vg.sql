
create view y_c_view1 as
SELECT   dbo.类别.类别名称, dbo.类别.类别ID, dbo.产品.产品ID, dbo.产品.产品名称, dbo.产品.单价, dbo.产品.库存量, 
                dbo.产品.订购量
FROM      dbo.产品 INNER JOIN
                dbo.类别 ON dbo.产品.类别ID = dbo.类别.类别ID
WHERE   (dbo.产品.产品名称 = '饮料')
go

